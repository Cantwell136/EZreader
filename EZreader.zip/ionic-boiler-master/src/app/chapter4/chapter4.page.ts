import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter4',
  templateUrl: './chapter4.page.html',
  styleUrls: ['./chapter4.page.scss'],
})
export class Chapter4Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
